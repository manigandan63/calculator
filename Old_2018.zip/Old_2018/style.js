﻿
	<!-- NUTRIANTS -->
		var checked= [];
		var numb = [];
		var numItems=0;	


			/** initial loading **/
			function not_specificcom()
			{
				checked= [];
				$("input:checkbox[name=check]:checked").prop("checked", false);
				$(".sel_align input:checkbox").prop("checked", true);
				$("input:checkbox[name=check]:not(:checked)").parent().css("opacity","0.5");
				$("input:checkbox[name=check]:checked").parent().css("opacity","1");
				$("input:checkbox[name=check]:checked").each(function(){
				checked.push($(this).val());
				});
				for(var i = 1; i<=33; i++){
				$(".checkbox"+i).hide();
				}
				for(var j=0; j<checked.length; j++){
				$("."+checked[j]).show();
				}
				$("#hun_main_menu_scroller_child").css({"height":"3630px"});
				$("#ps_main_menu_scroller_child").css({"height":"3630px"});
				myScroll1.refresh();
				myScroll2.refresh();							
				return;		
				
			}
			
			/** check box click unclick function**/
			function checkbox(element)
			{
				checked= [];			
				$("input:checkbox[name=check]:checked").each(function(){
				checked.push($(this).val());
				});
				$("input:checkbox[name=check]:not(:checked)").prop("disabled",false);
				$("input:checkbox[name=check]:not(:checked)").parent().css("opacity","0.5");
				$("input:checkbox[name=check]:checked").parent().css("opacity","1");
				
				for(var i = 1; i<=33; i++){
				$(".checkbox"+i).hide();
				}
				for(var j=0; j<checked.length; j++){
				$("."+checked[j]).show();
				}
				var divlnth=((checked.length*3630)/33);
				$("#hun_main_menu_scroller_child").css({"height":divlnth+"px"});
				$("#ps_main_menu_scroller_child").css({"height":divlnth+"px"});
				myScroll1.refresh();
				myScroll2.refresh();
			}
			
			
			/** width adjustment**/
			var clswidth=1;
			
			function closewidthmod()
			{
							clswidth=1;
							if($(".per100g").hasClass("per100g_selected"))
							{
							clswidth = (($('#hun_sub_main_menu #brands>div:visible').length)-2);
							}
							else if($(".perserve").hasClass("perserve_selected"))
							{
							clswidth = (($('#ps_sub_main_menu #brands>div:visible').length)-2);
							}
									if(clswidth==0)
									{
									$("#hun_main_menu_scroller, #hun_main_menu_scroller_child").css("width","253px");
									$("#ps_main_menu_scroller, #ps_main_menu_scroller_child").css("width","253px");
									}
									else if(clswidth==1)
									{
									$("#hun_main_menu_scroller, #hun_main_menu_scroller_child").css("width","450px");
									$("#ps_main_menu_scroller, #ps_main_menu_scroller_child").css("width","450px");
									}
									else if(clswidth==2)
									{
									$("#hun_main_menu_scroller, #hun_main_menu_scroller_child").css("width","648px");
									$("#ps_main_menu_scroller, #ps_main_menu_scroller_child").css("width","648px");
									}
									else if(clswidth==3){
									$("#hun_main_menu_scroller, #hun_main_menu_scroller_child").css("width","848px");
									$("#ps_main_menu_scroller, #ps_main_menu_scroller_child").css("width","848px");
									}
									return;
			}
			
			
			/** production selection **/
			var numItems=0;
			var custprod;
			function brands_sel(){
				return ($('.p1_brand_innerdiv .brandSelcted').length);
			}
			function selcalc(selectedproduct)
					{
					
				numItems=brands_sel();
				custprod=selectedproduct.substring(1, selectedproduct.length);
					if(!$(".switch input").is(":checked"))
				{
					if(numItems<=2 || $(""+selectedproduct).hasClass("brandSelcted")){	
					$(""+selectedproduct).toggleClass("brandSelcted");
					$(""+selectedproduct).toggleClass(""+custprod+"1");
					}
					else{
						$(".error_scrn_products").show();
					}
				}
				else
				{
					if(numItems==0 || $(""+selectedproduct).hasClass("brandSelcted")){
					$(""+selectedproduct).toggleClass("brandSelcted");
					$(""+selectedproduct).toggleClass(""+custprod+"1");
					}
					else{
					$(".error_scrn_specproducts").show();
					}
				}
				return;
					
					}
					
					
        $(document).ready(function(){
		
		
			 $(".checks").on("click", function(){
				checkbox(this);
            });
			
			$(".d_protin").on("click", function(){			
				selcalc(".d_protin");
            });
            $(".ensure").on("click", function(){
				selcalc(".ensure");
            });
            $(".penta_sure").on("click", function(){
				selcalc(".penta_sure");
            });			
			$(".resource").on("click", function(){
				selcalc(".resource");
            });
            $(".vidavance").on("click", function(){
				selcalc(".vidavance");
            });
            $(".prohance").on("click", function(){
				selcalc(".prohance");
            });
           			
			
           
			
			$(".per100g").on("click", function(){
                $(".per100g").toggleClass("per100g_selected");
				$(".perserve").removeClass("perserve_selected");
            });
			$(".perserve").on("click", function(){
                $(".perserve").toggleClass("perserve_selected");
				 $(".per100g").removeClass("per100g_selected");
            });
			
			<!-- PRODUCTS -->
			
            $(".com_button").on("click", function(){
				var numb = [];
                $(".com_button").addClass("com_button1");
				if($(".ensure").hasClass("ensure1")){
					numb.push(2);
				}
				if($(".d_protin").hasClass("d_protin1")){
					numb.push(3);
				}
				if($(".penta_sure").hasClass("penta_sure1")){
					numb.push(4);
				}
				if($(".resource").hasClass("resource1")){
					numb.push(5);
				}
				if($(".vidavance").hasClass("vidavance1")){
					numb.push(6);
				}
				if($(".prohance").hasClass("prohance1")){
					numb.push(7);
				}
				
				
				$(".brand2, .brand3, .brand4,.brand5,.brand6,.brand7").hide();
				if(numb.length!=0)
				{
				//console.log(numb);
					setTimeout(function(){
					
					if($(".per100g").hasClass("per100g_selected") || $(".perserve").hasClass("perserve_selected") )
					{
							if($(".per100g").hasClass("per100g_selected")){
								$('#per_hundred_content').show();
								$('#perscoop_content').hide();
							}
							else if($(".perserve").hasClass("perserve_selected")){
								$('#per_hundred_content').hide();
								$('#perscoop_content').show();
							}
							// not specific comparison//
							if(!$(".switch input").is(":checked"))
							{
							$(".fullclose").show();
							$(".checks").prop("disabled",false);
							myScroll1.scrollTo(0,0);
							myScroll2.scrollTo(0,0);
							//CFF//
							not_specificcom();
							$("#selection_menu_child").css({"height":"1195px"});
							myScroll.refresh();
							$("#selection_menu,.brand0").show();
							$(".brand00").hide();
							$("#ps_main_menu,#hun_main_menu").css("left","0px");
							$(".wrapper1").fadeIn();
							$(".btm_1").show();
							$(".specbtm").hide();
								setTimeout(function(){
								reset_prodsel();
								$(".switch input").prop("checked",false);
								},300);	
								for(var i =0; i < numb.length; i++){
								$(".brand"+numb[i]).show();
								}
								closewidthmod();
							}
							/** specific comparison**/
							else
							{
							if(numb.length==1)
							{
							for(var i = 1; i<=33; i++){
							$(".checkbox"+i).show();
							}
							$(".fullclose").hide();
							$(".checks").prop("disabled",true).prop("checked",false);
							$("input:checkbox[name=check]:not(:checked)").parent().css("opacity","0.5");
							$("#hun_main_menu_scroller, #ps_main_menu_scroller").css({"width":"848px","overflow":"hidden"});
							$("#hun_main_menu_scroller_child, #ps_main_menu_scroller_child ").css({"width":"848px","height":"3630px"});	
							$("#selection_menu_child").css({"height":"500px"});	
							myScroll1.refresh();
							myScroll2.refresh();
							$("#selection_menu,.brand0").hide();
							$(".brand00").show();
							$("#ps_main_menu,#hun_main_menu").css("left","-160px");
							$("#ps_main_menu_scroller, #ps_main_menu_scroller_child").css("width","613px");
							$("#hun_main_menu_scroller, #hun_main_menu_scroller_child").css("width","613px");
								specific_comparision();
								$(".wrapper1").fadeIn();
								$(".btm_1").hide();
								$(".specbtm").show();
								for(var i =0; i < numb.length; i++){
								$(".brand"+numb[i]).show();
								}							
							}							
							else
							{
							$(".error_scrn_specproducts").show();
							}							
							}	
							}
						else {$(".error_scrn_measure").show(); }
						},200);						
						}
				else{
					$(".error_scrn").show();
					}
				$(".errorscrn_close").on("click", function(){
					$(".error_scrn").hide(); 
					$(".com_button").removeClass("com_button1");
				});	
				$(".errorscrnmeasure_close").on("click", function(){
					$(".error_scrn_measure").hide();
					$(".com_button").removeClass("com_button1");
				});
				$(".errorscrnnutrients_close").on("click", function(){
					$(".error_scrn_nutrients").hide();
					
				});
            });
			$(".errorscrnproducts_close").on("click", function(){
					$(".error_scrn_products").hide();
				});	
				$(".error_scrn_specproducts_close").on("click", function(){
					$(".error_scrn_specproducts").hide();
					$(".com_button").removeClass("com_button1");
				});
			/* inner page close*/
			$(".gotoscreen1").on("click", function(){				
				$(".wrapper1").fadeOut();
				$(".ensure").removeClass("ensure1 brandSelcted");
				$(".d_protin").removeClass("d_protin1 brandSelcted");
				$(".penta_sure").removeClass("penta_sure1 brandSelcted");
				$(".resource").removeClass("resource1 brandSelcted");
				$(".vidavance").removeClass("vidavance1 brandSelcted");
				$(".prohance").removeClass("prohance1 brandSelcted");
				$(".com_button").removeClass("com_button1");
			});			
		
			$(".ensure_close").on("click", function(){
				$(".brand2").hide();
				closewidthmod();
			});
			$(".d_protin_close").on("click", function(){
				$(".brand3").hide();
				closewidthmod();
			});
			$(".penta_sure_close").on("click", function(){
				$(".brand4").hide();
				closewidthmod();
			});
			$(".resource_close").on("click", function(){
				$(".brand5").hide();
				closewidthmod();
			});
			$(".vidavance_close").on("click", function(){
				$(".brand6").hide();
				closewidthmod();
			});
			$(".prohance_close").on("click", function(){
				$(".brand7").hide();
				closewidthmod();
			});
			
			
							
			
			/** page1 Scroll Section**/
			var newpo=0;
			$(".left_arrow").on("click", function(){			
				if(newpo!=0){
					newpo=newpo+206;
					var s = "translate3d(" + newpo + "px, 0, 0)";
					$('.p1_brand_innerdiv ').css('-webkit-transform', s);
				}
				else{//alert("right");
				}
			});
			$(".right_arrow").on("click", function(){
				if(newpo!=-618){
					newpo=newpo-206;
					var s = "translate3d(" + newpo + "px, 0, 0)";
					$('.p1_brand_innerdiv ').css('-webkit-transform', s);
				}
				else{//alert();
				}
			});
			myScroll = new iScroll('selection_menu_parent');
			myScroll1 = new iScroll('hun_main_menu_scroller');
			myScroll2 = new iScroll('ps_main_menu_scroller');
					function reset_prodsel()
					{	
					while(newpo!=0)
					{
					newpo=newpo+206;
					var s = "translate3d(" + newpo + "px, 0, 0)";
					$('.p1_brand_innerdiv ').css('-webkit-transform', s);
					}
					return;
					}
					
					function specific_comparision()
					{
						
						
						if($(".per100g").hasClass("per100g_selected") )
						{
							if($(".ensure ").hasClass("ensure1")){
							$(".hun_ensure").hide();
							specificcompdiv(".hun_ensure");	
							}
							else if($(".d_protin").hasClass("d_protin1")){
							$(".hun_d_protin").hide();
							specificcompdiv(".hun_d_protin");	
							}							 
							else if($(".penta_sure").hasClass("penta_sure1")){
							$(".hun_penta_sure").hide();
							specificcompdiv(".hun_penta_sure");	
							}
							else if($(".resource ").hasClass("resource1")){
							$(".hun_resource").hide();
							specificcompdiv(".hun_resource");	
							}
							else if($(".vidavance").hasClass("vidavance1")){
							$(".hun_vidavance").hide();
							specificcompdiv(".hun_vidavance");							
							}
							else if($(".prohance").hasClass("prohance1")){
							$(".hun_prohance").hide();
							specificcompdiv(".hun_prohance");							
							}

							return;
						}
						else if($(".perserve").hasClass("perserve_selected") )
						{
							
							if($(".ensure ").hasClass("ensure1")){
							$(".ps_ensure").hide();
							specificcompdiv(".ps_ensure");	
							}
							else if($(".d_protin").hasClass("d_protin1")){
							$(".ps_d_protin").hide();
							specificcompdiv(".ps_d_protin");	
							}
							else if($(".penta_sure").hasClass("penta_sure1")){
							$(".ps_penta_sure").hide();
							specificcompdiv(".ps_penta_sure");	
							}
							else if($(".resource ").hasClass("resource1")){
							$(".ps_resource").hide();
							specificcompdiv(".ps_resource");	
							}
							else if($(".vidavance").hasClass("vidavance1")){
							$(".ps_vidavance").hide();
							specificcompdiv(".ps_vidavance");							
							}
							else if($(".prohance").hasClass("prohance1")){
							$(".ps_prohance").hide();
							specificcompdiv(".ps_prohance");							
							}
							
							
							return;
						}
						
					}
					
					/** specific comparision div lenght **/
					function specificcompdiv(compdiv)
					{
							var specdivlength=(((33-$(""+compdiv).length)*3630)/33);
							$("#ps_main_menu_scroller_child,#hun_main_menu_scroller_child").css({"height":specdivlength+"px"});
							return;
					}
							
			});